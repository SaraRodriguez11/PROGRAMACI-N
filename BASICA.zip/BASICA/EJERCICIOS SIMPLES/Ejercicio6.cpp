//Escribir un programa que calcule el �rea de un rect�ngulo de 
//lado1 = 3 y lado2 = 4. �rea del rect�ngulo=lado1 * lado2

#include <iostream>
using namespace std; 
int main (){
	
	int lado1 = 3;
	int lado2 = 4; 
	
	cout<<"EL area del rectangulo es:"<< lado1 * lado2 <<endl; 
	
	system ("pause"); 
	return 0; 
}
